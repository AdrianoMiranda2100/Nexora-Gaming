# Histórico de versões — Nexora Gaming

## 3.0.0 — Upgrade visual e motion design
- Refinamento do sistema de design Frutiger Aero + Liquid Glass.
- Nova seção “Nexora Experience” na Home.
- Nova seção de equipe na página Sobre, com os dois autores do projeto.
- Indicador de progresso de rolagem.
- Revelação progressiva de blocos conforme entram na tela.
- Microinterações e efeito de reflexo nos componentes de vidro.
- Inclinação sutil dos cards de produtos com ponteiro em desktop.
- Anime.js 4 carregado pelo CDN oficial, com fallback para CSS/JavaScript nativo.
- Ajustes responsivos, melhorias de foco, navegação por teclado e respeito a `prefers-reduced-motion`.
- Créditos da equipe e metadados de autoria nas páginas.
