(() => {
  'use strict';

  const PRODUCT_LIST = Array.isArray(window.NEXORA_PRODUCTS) ? window.NEXORA_PRODUCTS : [];
  const CART_KEY = 'nexora-gaming-cart-v2';
  const formatMoney = value => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  const findProduct = id => PRODUCT_LIST.find(product => product.id === id);

  function readCart() {
    try {
      const value = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      return Array.isArray(value) ? value.filter(item => findProduct(item.id) && Number.isInteger(item.quantity) && item.quantity > 0) : [];
    } catch (_error) { return []; }
  }
  function saveCart(cart) {
    try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); }
    catch (_error) { showToast('O navegador não permitiu salvar a sacola nesta sessão.'); }
    updateCartCounts(cart);
  }
  function updateCartCounts(cart = readCart()) {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelectorAll('[data-cart-count]').forEach(node => { node.textContent = String(count); });
    document.querySelectorAll('[data-cart-item-count]').forEach(node => { node.textContent = String(count); });
  }
  let toastTimer;
  function showToast(message) {
    const toast = document.querySelector('[data-toast]');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 2900);
  }
  function addToCart(id) {
    const product = findProduct(id);
    if (!product) return showToast('Não foi possível encontrar esse item.');
    const cart = readCart();
    const existing = cart.find(item => item.id === id);
    if (existing) existing.quantity += 1;
    else cart.push({ id, quantity: 1 });
    saveCart(cart);
    showToast(`${product.name} foi adicionado à sua sacola.`);
  }

  // Menu responsivo e estado ativo da rota.
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.primary-nav');
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      const open = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!open));
      menuToggle.setAttribute('aria-label', open ? 'Abrir menu' : 'Fechar menu');
      nav.classList.toggle('is-open', !open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.setAttribute('aria-label', 'Abrir menu');
      nav.classList.remove('is-open');
    }));
  }
  const path = window.location.pathname.replace(/\/$/, '') || '/';
  document.querySelectorAll('[data-nav-link]').forEach(link => {
    if (link.getAttribute('data-nav-link') === path) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });

  // Catálogo: pesquisa, filtros por categoria e leitura do parâmetro ?categoria=.
  const catalog = document.querySelector('[data-catalog]');
  if (catalog) {
    const cards = Array.from(catalog.querySelectorAll('[data-product-card]'));
    const searchInput = document.querySelector('[data-product-search]');
    const filters = Array.from(document.querySelectorAll('[data-filter]'));
    const resultCount = document.querySelector('[data-results-count]');
    const emptyResults = document.querySelector('[data-empty-results]');
    const params = new URLSearchParams(window.location.search);
    let category = params.get('categoria') || 'all';
    if (!filters.some(button => button.dataset.filter === category)) category = 'all';
    let searchTerm = '';

    function applyFilters() {
      let visible = 0;
      cards.forEach(card => {
        const matchCategory = category === 'all' || card.dataset.category === category;
        const matchSearch = (card.dataset.search || '').includes(searchTerm);
        const show = matchCategory && matchSearch;
        card.hidden = !show;
        if (show) visible += 1;
      });
      filters.forEach(button => {
        const active = button.dataset.filter === category;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', String(active));
      });
      if (resultCount) resultCount.textContent = `${visible} ${visible === 1 ? 'item' : 'itens'}`;
      if (emptyResults) emptyResults.hidden = visible !== 0;
    }
    filters.forEach(button => button.addEventListener('click', () => {
      category = button.dataset.filter || 'all';
      applyFilters();
    }));
    if (searchInput) searchInput.addEventListener('input', () => {
      searchTerm = searchInput.value.trim().toLocaleLowerCase('pt-BR');
      applyFilters();
    });
    applyFilters();
  }

  // Adicionar produtos à sacola a partir de qualquer cartão.
  document.querySelectorAll('[data-add-to-cart]').forEach(button => {
    button.addEventListener('click', () => addToCart(button.getAttribute('data-add-to-cart')));
  });

  // Página de detalhe compartilhada, servida pela rota /produto?slug=...
  const detailMount = document.querySelector('[data-product-detail]');
  if (detailMount) {
    const slug = new URLSearchParams(window.location.search).get('slug');
    const product = PRODUCT_LIST.find(item => item.slug === slug);
    const crumb = document.querySelector('[data-product-breadcrumb]');
    if (!product) {
      detailMount.innerHTML = '<div class="not-found-card glass-panel"><span class="eyebrow">ITEM NÃO ENCONTRADO</span><h2>Este produto saiu de órbita.</h2><p class="page-lead">Confira o catálogo e escolha outro favorito.</p><a class="button button-primary" href="/produtos">Voltar ao catálogo ↗</a></div>';
    } else {
      document.title = `${product.name} | Nexora Gaming`;
      if (crumb) crumb.textContent = product.name;
      const oldPrice = product.oldPrice ? `<del>${formatMoney(product.oldPrice)}</del>` : '';
      const features = product.features.map(feature => `<li>${escapeHtml(feature)}</li>`).join('');
      detailMount.innerHTML = `<div class="product-detail-layout"><div class="detail-art glass-panel"><img src="${product.image}" alt="Ilustração do produto ${escapeHtml(product.name)}"></div><section class="detail-content"><span class="eyebrow">${escapeHtml(product.categoryLabel.toUpperCase())} · NEXORA SELECT</span><h1>${escapeHtml(product.name)}</h1><p>${escapeHtml(product.description)}</p><div class="detail-price">${oldPrice}<strong>${formatMoney(product.price)}</strong></div><button class="add-button" type="button" data-add-to-cart="${product.id}"><span aria-hidden="true">＋</span> Adicionar à sacola</button><a class="button button-glass" href="/produtos">Voltar ao catálogo</a><ul class="detail-features">${features}</ul><p class="detail-note">Projeto escolar demonstrativo. Produto e preço fictícios; nenhuma transação será realizada.</p></section></div>`;
      const addButton = detailMount.querySelector('[data-add-to-cart]');
      if (addButton) addButton.addEventListener('click', () => addToCart(product.id));
    }
  }

  // Renderiza a sacola. As quantidades são persistidas apenas no navegador atual.
  const cartMount = document.querySelector('[data-cart-items]');
  if (cartMount) {
    const emptyPanel = document.querySelector('[data-cart-empty]');
    const subtitle = document.querySelector('[data-cart-subtitle]');
    const subtotalNode = document.querySelector('[data-cart-subtotal]');
    const totalNode = document.querySelector('[data-cart-total]');
    function renderCart() {
      const cart = readCart();
      const count = cart.reduce((sum, item) => sum + item.quantity, 0);
      const subtotal = cart.reduce((sum, item) => sum + findProduct(item.id).price * item.quantity, 0);
      cartMount.innerHTML = cart.map(item => {
        const product = findProduct(item.id);
        return `<article class="cart-item" data-cart-id="${product.id}"><a class="cart-item-art" href="/produto?slug=${product.slug}" aria-label="Ver ${escapeHtml(product.name)}"><img src="${product.image}" alt=""></a><div class="cart-item-info"><h3><a href="/produto?slug=${product.slug}">${escapeHtml(product.name)}</a></h3><p>${escapeHtml(product.categoryLabel)}</p><div class="cart-item-price">${formatMoney(product.price * item.quantity)}</div><div class="cart-item-controls"><button class="quantity-button" type="button" data-quantity="-1" data-id="${product.id}" aria-label="Diminuir quantidade de ${escapeHtml(product.name)}">−</button><span class="quantity-value">${item.quantity}</span><button class="quantity-button" type="button" data-quantity="1" data-id="${product.id}" aria-label="Aumentar quantidade de ${escapeHtml(product.name)}">＋</button><button class="remove-button" type="button" data-remove-item="${product.id}">Remover</button></div></div><div class="cart-item-trailing"><strong>${formatMoney(product.price * item.quantity)}</strong></div></article>`;
      }).join('');
      if (emptyPanel) emptyPanel.hidden = count !== 0;
      cartMount.hidden = count === 0;
      if (subtitle) subtitle.textContent = `${count} ${count === 1 ? 'item selecionado' : 'itens selecionados'}`;
      if (subtotalNode) subtotalNode.textContent = formatMoney(subtotal);
      if (totalNode) totalNode.textContent = formatMoney(subtotal);
      updateCartCounts(cart);
      cartMount.querySelectorAll('[data-quantity]').forEach(button => button.addEventListener('click', () => {
        const delta = Number(button.dataset.quantity);
        const id = button.dataset.id;
        const updated = readCart().map(item => item.id === id ? { ...item, quantity: item.quantity + delta } : item).filter(item => item.quantity > 0);
        saveCart(updated); renderCart();
      }));
      cartMount.querySelectorAll('[data-remove-item]').forEach(button => button.addEventListener('click', () => {
        saveCart(readCart().filter(item => item.id !== button.dataset.removeItem));
        showToast('Item removido da sacola.'); renderCart();
      }));
    }
    renderCart();
    const checkout = document.querySelector('[data-demo-checkout]');
    if (checkout) checkout.addEventListener('click', () => showToast(readCart().length ? 'Demonstração concluída! Nenhuma compra real foi realizada.' : 'Sua sacola está vazia. Explore o catálogo primeiro.'));
  }

  // Formulários de demonstração: mostram retorno visual e não enviam dados.
  function attachDemoForm(form, feedbackSelector, message) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const feedback = feedbackSelector ? document.querySelector(feedbackSelector) : null;
      if (feedback) feedback.textContent = message;
      form.reset();
      showToast(message);
    });
  }
  const contactForm = document.querySelector('[data-contact-form]');
  if (contactForm) attachDemoForm(contactForm, '[data-contact-feedback]', 'Mensagem validada na demonstração. Nenhum dado foi enviado.');
  document.querySelectorAll('[data-demo-form]').forEach(form => attachDemoForm(form, '[data-form-feedback]', 'Cadastro demonstrativo concluído. Nenhum dado foi enviado.'));

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }


  // NEXORA V3 motion system — Anime.js enhancement with a native CSS fallback.
  const reduceMotionPreference = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const animeEngine = window.anime && typeof window.anime.animate === 'function' ? window.anime : null;

  function setupV3Motion() {
    const progressBar = document.querySelector('[data-scroll-progress]');
    let scrollTicking = false;
    const updateProgress = () => {
      if (!progressBar) return;
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      const progress = scrollable > 0 ? Math.min(100, Math.max(0, window.scrollY / scrollable * 100)) : 0;
      progressBar.style.setProperty('--scroll-progress', `${progress}%`);
      progressBar.style.width = `${progress}%`;
      scrollTicking = false;
    };
    updateProgress();
    window.addEventListener('scroll', () => {
      if (!scrollTicking) {
        scrollTicking = true;
        window.requestAnimationFrame(updateProgress);
      }
    }, { passive: true });
    window.addEventListener('resize', updateProgress, { passive: true });

    // Staggered reveal of meaningful page regions and product cards.
    const revealSelectors = [
      '.hero-copy > *', '.hero-proof', '.trust-strip > div', '.section-heading',
      '.product-card', '.category-tile', '.category-detail', '.value-card',
      '.support-card', '.faq-item', '.promo-banner', '.about-showcase', '.team-card',
      '.experience-copy > *', '.experience-window', '.contact-form-card',
      '.contact-aside-card', '.cart-items-panel', '.cart-summary',
      '.product-detail-layout > *', '.not-found-card', '.info-note', '.offer-callout'
    ];
    const revealElements = [];
    revealSelectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(element => {
        if (!revealElements.includes(element)) revealElements.push(element);
      });
    });
    revealElements.forEach((element, index) => {
      element.setAttribute('data-reveal', '');
      element.dataset.revealDelay = String(Math.min((index % 6) * 58, 290));
    });

    if (reduceMotionPreference || !('IntersectionObserver' in window)) {
      revealElements.forEach(element => element.classList.add('is-revealed'));
    } else {
      document.body.classList.add('motion-ready');
      const revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          const element = entry.target;
          revealObserver.unobserve(element);
          const delay = Number(element.dataset.revealDelay || 0);
          if (animeEngine) {
            animeEngine.animate(element, {
              opacity: [0, 1],
              y: [25, 0],
              duration: 760,
              delay,
              ease: 'outExpo',
              onComplete: () => element.classList.add('is-revealed')
            });
          } else {
            element.classList.add('is-revealed');
          }
        });
      }, { rootMargin: '0px 0px -7% 0px', threshold: 0.08 });
      revealElements.forEach(element => revealObserver.observe(element));
    }

    // Mouse-position highlights recreate a soft, responsive glass sheen.
    const spotlightElements = document.querySelectorAll('.product-card, .category-tile, .category-detail, .support-card, .value-card, .glass-panel');
    spotlightElements.forEach(element => {
      element.addEventListener('pointermove', event => {
        if (event.pointerType && event.pointerType !== 'mouse') return;
        const rect = element.getBoundingClientRect();
        const x = Math.max(0, Math.min(rect.width, event.clientX - rect.left));
        const y = Math.max(0, Math.min(rect.height, event.clientY - rect.top));
        element.style.setProperty('--pointer-x', `${x}px`);
        element.style.setProperty('--pointer-y', `${y}px`);
        if (element.classList.contains('product-card') && !reduceMotionPreference) {
          const rotateY = ((x / Math.max(rect.width, 1)) - 0.5) * 3.2;
          const rotateX = (0.5 - (y / Math.max(rect.height, 1))) * 3.2;
          element.style.setProperty('--tilt-x', `${rotateX.toFixed(2)}deg`);
          element.style.setProperty('--tilt-y', `${rotateY.toFixed(2)}deg`);
        }
      }, { passive: true });
      element.addEventListener('pointerleave', () => {
        element.style.removeProperty('--tilt-x');
        element.style.removeProperty('--tilt-y');
      }, { passive: true });
    });

    // Small button ripple. The animation is decorative and ignored by assistive tech.
    if (!reduceMotionPreference) {
      document.querySelectorAll('.button, .add-button, .filter-chip, .cart-link').forEach(button => {
        button.addEventListener('pointerdown', event => {
          if (event.pointerType && event.pointerType !== 'mouse') return;
          const rect = button.getBoundingClientRect();
          const ripple = document.createElement('span');
          ripple.className = 'tap-ripple';
          ripple.setAttribute('aria-hidden', 'true');
          ripple.style.left = `${event.clientX - rect.left}px`;
          ripple.style.top = `${event.clientY - rect.top}px`;
          button.appendChild(ripple);
          ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
        });
      });
    }

    // Tiny first-load entrance flourish for the brand mark, gracefully optional.
    const mark = document.querySelector('.brand-mark');
    if (mark && animeEngine && !reduceMotionPreference) {
      animeEngine.animate(mark, { scale: [0.82, 1], rotate: ['-8deg', '0deg'], duration: 650, ease: 'outBack', delay: 80 });
    }

    // Escape closes the mobile navigation to improve keyboard usability.
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && menuToggle && nav && menuToggle.getAttribute('aria-expanded') === 'true') {
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.setAttribute('aria-label', 'Abrir menu');
        nav.classList.remove('is-open');
        menuToggle.focus();
      }
    });
  }

  setupV3Motion();

  updateCartCounts();
})();
