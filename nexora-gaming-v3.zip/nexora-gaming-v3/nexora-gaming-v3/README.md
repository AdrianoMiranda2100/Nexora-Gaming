# Nexora Gaming — Versão 3.0

Loja gamer demonstrativa construída com HTML5, CSS3, JavaScript puro e Express. Identidade visual: **Frutiger Aero + Liquid Glass**, com movimentos fluidos, reflexos dinâmicos, superfícies translúcidas e componentes responsivos.

## Equipe
- Adriano Costa de Miranda
- João Cordeiro de Lima Assunção

## Executar no VS Code / Windows
1. Extraia o projeto e abra a pasta `nexora-gaming-v3` no VS Code.
2. Abra o terminal na pasta que contém `server.js` e `package.json`.
3. Instale as dependências:

```powershell
npm.cmd install
```

> No PowerShell do Windows, se `npm install` for bloqueado pela política de scripts, `npm.cmd install` evita chamar o script `npm.ps1`.

4. Inicie o servidor:

```powershell
node server.js
```

5. Acesse `http://localhost:3000`.

## Rotas
| Página | Rota |
|---|---|
| Início | `/` |
| Produtos | `/produtos` |
| Categorias | `/categorias` |
| Ofertas | `/ofertas` |
| Jogos | `/jogos` |
| Sobre nós | `/sobre` |
| Suporte | `/suporte` |
| Contato | `/contato` |
| Sacola demonstrativa | `/carrinho` |
| Detalhe do produto | `/produto?slug=aurora-x` |

## Destaques da V3
- Sistema visual mais consistente: brilhos, profundidade, transparências, gradientes aquáticos e sombras suaves.
- Microinterações em botões, menu, cards e categorias.
- Anime.js v4 para entradas e transições quando o CDN estiver disponível; animações CSS e comportamento básico permanecem como fallback.
- Indicador de progresso de rolagem e revelação progressiva de conteúdo.
- Efeito de reflexo que acompanha o ponteiro e inclinação sutil nos cards de produto em desktop.
- Suporte a `prefers-reduced-motion`, navegação por teclado e layouts para telas pequenas.
- Nova seção de experiência na Home e seção de equipe na página Sobre.
- Créditos dos dois alunos no rodapé e na página Sobre.

## Estrutura
```text
nexora-gaming-v3/
├── server.js
├── package.json
├── package-lock.json
├── README.md
└── src/
    ├── public/
    │   ├── css/index.css
    │   ├── js/app.js
    │   ├── js/products.js
    │   ├── images/
    │   └── paginas/
    └── plano/
```

O `server.js` contém somente configuração do Express, arquivos estáticos, rotas e fallback 404. Cada página HTML fica separada. O CSS fica em `src/public/css/index.css` e os scripts do navegador em `src/public/js/`.

## Referências de inspiração
- Uiverse — componentes de interface e padrões de glassmorphism: https://uiverse.io/
- Anime.js — documentação e distribuição UMD: https://animejs.com/documentation/getting-started/installation/

**Aviso:** Nexora Gaming, produtos, jogos, preços e ofertas são fictícios. Formulários e sacola são demonstrativos e não processam compras reais. Anime.js é carregado de CDN; para a biblioteca de animação, é necessária conexão à internet. Os estilos e interações principais têm fallback CSS/nativo.
